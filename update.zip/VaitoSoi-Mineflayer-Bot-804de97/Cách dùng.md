# Cách dùng code Mineflayer-Bot

#### Yêu cầu:

* Đã tải [NodeJS](https://nodejs.org/en/) cho việc chạy chương trình.
* Tải [VSCode (Visual Studio Code)](https://code.visualstudio.com/) cho việc chỉnh sửa (không cần thiết)
* Tải [Repository này](https://github.com/VaitoSoi/Mineflayer-Bot) (để có chương trình mà chạy)

#### Bước 1: Sửa dụng

###### Nếu bạn dùng máy tính chạy hệ điều hành Window:

* Chạy file `start.bat` hoặc `start`

![File start](https://cdn.discordapp.com/attachments/936994810450042931/1015898633331298395/unknown.png)

###### Nếu bạn dùng hệ điều hành khác Window hoặc muốn làm màu

* Mở `cmd` hoặc `bash`

* Dẫn đến nơi chứa file (thường là lệnh `cd`)

* Dùng lệnh `node index.js`

## Lưu ý:

* Code này được thiết kế cho việc chạy trong server anarchyvn.net. Nếu bạn muốn chạy trong server của mình thì hãy liên hệ VaitoSoi#2220