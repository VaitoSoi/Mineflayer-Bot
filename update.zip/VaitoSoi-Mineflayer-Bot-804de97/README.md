# Mineflayer basic bot
##### Dễ hiểu thì code này dùng để cho bot Mineflayer chạy trong các server minecraft.
##### !! Lưu ý: Chỉ nên chạy bot này trong server anarchyvn.net!

* **Lưu ý: Có sử dụng code [2Y2C-Login-API](https://github.com/MoonVN571/2Y2C-Login-API).**
* **Chỉ mang tính chất tham khảo.**
* **Nếu có dùng vui lòng ghi Credit (VaitoSoi#2220).**
* **Đọc kỹ ["Hướng dẫn sử dụng"](https://github.com/VaitoSoi/Mineflayer-Bot/blob/main/C%C3%A1ch%20d%C3%B9ng.md) trước khi dùng.**
